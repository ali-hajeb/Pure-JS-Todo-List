# Pure-JS-Todo-List
A simple todo list built by pure JS, HTML and CSS.

## Usage
After cloning the repository, open index.html.

### Add a task
In "New Task" section, enter required data then click on "Add to list".

### Edit a task
Click on "Edit" button inside desired task card. Edit the task details in "edit dialogue", then press "Edit" button.

### Delete a task
Click on "Delete" button inside desired task card.

### Complete a task
Click on the square in the top right section of desired task.

Icons by [Bootstrap icons](https://icons.getbootstrap.com/).